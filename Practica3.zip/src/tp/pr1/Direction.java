package tp.pr1;

/**
 * @author Sergio Ulloa
 */
public enum Direction {
	UP, DOWN, LEFT, RIGHT;
}
