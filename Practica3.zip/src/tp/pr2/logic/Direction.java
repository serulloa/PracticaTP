package tp.pr2.logic;

/**
 * @author Sergio Ulloa
 */
public enum Direction {
	UP, DOWN, LEFT, RIGHT;
}
