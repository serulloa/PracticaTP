package tp.pr2.logic.multigames;

/**
 * @author Sergio Ulloa
 */
public enum GameType {
	ORIG, FIB, INV;
}
